<?php 
session_start();
if (!isset($_SESSION["password"])) {
 header("location:user.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
	<title>Delete Exported Furniture</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="layout">
	<div class="bunner"><center><h1>Welcome To Cargo Ltd</h1></center></div>
	<div class="menu"><?php  include "menu.php";  ?></div>
	<div class="content">
		<center>
			<h1><u>Delete Exported Furniture</u></h1>
			<form method="POST">
				<table bgcolor="pink">
					<tr><td><select name="sel">
						<option>Choose Furniture Name</option>
						<?php
						include "connection.php";
$query=mysqli_query($con,"SELECT * from import inner join export inner join furniture on furniture.f_id=import.f_id and furniture.f_id=export.f_id ");
while ($row=mysqli_fetch_array($query)) {
						?>
						<option><?php  echo $row["f_name"];  ?></option>
					<?php } ?>
					</select>
					<input type="submit" name="chkbtn" value="Check">
					</td>
				</tr>
				</table>
			</form>
<br>
			<?php
include "connection.php";
if (isset($_POST["chkbtn"])) {
	$query=mysqli_query($con,"SELECT * from import inner join export inner join furniture on furniture.f_id=import.f_id and furniture.f_id=export.f_id where f_name='$_POST[sel]'");
while ($row=mysqli_fetch_array($query)) {
			?>
			<form method="POST"> 	
				<table bgcolor="pink">
					<tr><td></td><td><input type="hidden" name="fid" value="<?php  echo $row['f_id']; ?>"></td></tr>
					<tr><td>Furniture Name</td><td><input type="text" name="fname" value="<?php  echo $row['f_name']; ?>"></td></tr>
					<tr><td>Furniture Owner Name</td><td><input type="text" name="owner" placeholder="Enter Furniture Owner Name" required="" value="<?php  echo $row['f_owner_name']; ?>"></td></tr>
					<tr><td>Import Date</td><td><input type="date" name="date1" value="<?php echo $row['i_date']; ?>" readonly></td></tr>
					<tr><td>Import Quantity</td><td><input type="number" name="qty" value="<?php echo $row['i_quantity']; ?>" readonly></td></tr>
					<tr><td>Exported Date</td><td><input type="date" name="edate1" value="<?php echo $row['e_date'];  ?>" readonly></td></tr>
					<tr><td>Exported Quantity</td><td><input type="number" name="eqty" value="<?php echo $row['e_quantity'];  ?>" readonly></td></tr>
					<tr><td></td><td><input type="submit" name="savebtn" value="Delete"></td></tr>
				</table>
			</form>
		<?php }} ?>
		<?php
include "connection.php";
if (isset($_POST["savebtn"])) {
	$quantity1=$_POST["qty"];
	$quantity2=$_POST["eqty"];
	if ($quantity2<=$quantity1) {
	$query=mysqli_query($con,"Delete from  export where f_id='$_POST[fid]'");
	if ($query) {
		echo "<script>alert('Delete Exported Furniture Successfully')</script>";
	}
}
else{
	echo "<script>alert('Exported Qty Is Higher Than Emported Qty')</script>";
}
}
		?>
		</center>
	</div>
	<div class="footer"><center><p>All@reserved by Cargo Ltd</p></center></div>
</div>
</body>
</html>
<?php
}
?>