<?php 
session_start();
if (!isset($_SESSION["password"])) {
 header("location:user.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update IMported Furniture</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="layout">
	<div class="bunner"><center><h1>Welcome To Cargo Ltd</h1></center></div>
	<div class="menu"><?php  include "menu.php";  ?></div>
	<div class="content">
		<center>
			<h1><u>Update IMported Furniture</u></h1>
			<form method="POST">
				<table bgcolor="pink">
					<tr><td><select name="sel">
						<option>Choose Furniture Name</option>
						<?php
						include "connection.php";
$query=mysqli_query($con,"SELECT * from import inner join furniture on furniture.f_id=import.f_id ");
while ($row=mysqli_fetch_array($query)) {
						?>
						<option><?php  echo $row["f_name"];  ?></option>
					<?php } ?>
					</select>
					<input type="submit" name="chkbtn" value="Check">
					</td>
				</tr>
				</table>
			</form>
<br>
			<?php
include "connection.php";
if (isset($_POST["chkbtn"])) {
	$query=mysqli_query($con,"SELECT * from import inner join furniture on furniture.f_id=import.f_id where f_name='$_POST[sel]'");
while ($row=mysqli_fetch_array($query)) {
			?>
			<form method="POST"> 	
				<table bgcolor="pink">
					<tr><td></td><td><input type="hidden" name="fid" value="<?php  echo $row['f_id']; ?>"></td></tr>
					<tr><td>Furniture Name</td><td><input type="text" name="fname" value="<?php  echo $row['f_name']; ?>" readonly></td></tr>
					<tr><td>Furniture Owner Name</td><td><input type="text" name="owner" placeholder="Enter Furniture Owner Name" required="" value="<?php  echo $row['f_owner_name']; ?>" readonly></td></tr>
					<tr><td>Import Date</td><td><input type="date" name="date1" value="<?php echo $row['i_date']; ?>"></td></tr>
					<tr><td>Import Quantity</td><td><input type="number" name="qty" value="<?php echo $row['i_quantity']; ?>"></td></tr>
					<tr><td></td><td><input type="submit" name="savebtn" value="Update"></td></tr>
				</table>
			</form>
		<?php }} ?>
		<?php
include "connection.php";
if (isset($_POST["savebtn"])) {
	$query=mysqli_query($con,"UPDATE import set i_date='$_POST[date1]',i_quantity='$_POST[qty]' where f_id='$_POST[fid]'");
	if ($query) {
		echo "<script>alert('Update Imported Furniture Successfully')</script>";
	}
}
		?>
		</center>
	</div>
	<div class="footer"><center><p>All@reserved by Cargo Ltd</p></center></div>
</div>
</body>
</html>
<?php
}
?>