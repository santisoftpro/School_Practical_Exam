<?php 
session_start();
if (!isset($_SESSION["password"])) {
 header("location:user.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
	<title>New Furniture</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="layout">
	<div class="bunner"><center><h1>Welcome To Cargo Ltd</h1></center></div>
	<div class="menu"><?php  include "menu.php";  ?></div>
	<div class="content">
		<center> <h1><u>New Furniture</u></h1>
			<form method="POST">
				<table bgcolor="pink">
					<tr><td>Furniture Name</td><td><input type="text" name="fname" placeholder="Enter Furniture Name" required=""></td></tr>
					<tr><td>Furniture Owner Name</td><td><input type="text" name="owner" placeholder="Enter Furniture Owner Name" required=""></td></tr>
					<tr><td></td><td><input type="submit" name="savebtn" value="Save"></td></tr>
				</table>
			</form>
			<?php
include "connection.php";
if (isset($_POST["savebtn"])) {
	$query=mysqli_query($con,"INSERT into furniture values('','$_POST[fname]','$_POST[owner]')");
	if ($query) {
		echo "<script>alert('Furniture Saved Successfully')</script>";
	}
}

			?>
		</center>
	</div>
	<div class="footer"><center><p>All@reserved by Cargo Ltd</p></center></div>
</div>
</body>
</html>
<?php
}
?>