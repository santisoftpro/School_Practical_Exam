	<div class="dropdown">
			<button class="dropbtn">FURNITURE</button>
			<div class="dropdown-content">
				<a href="newfurniture.php">New Furniture</a>
				<a href="viewfurniture.php">View Furniture</a>
				<a href="updatefurniture.php">Update Furniture</a>
				<a href="deletefurniture.php">Delete Furniture</a>
			</div>
		</div>
		<div class="dropdown">
					<button class="dropbtn">IMPORT</button>
			<div class="dropdown-content">
				<a href="newimport.php">New Import</a>
				<a href="viewimport.php">View Import</a>
				<a href="updateimport.php">Update Import</a>
				<a href="deleteimport.php">Delete Import</a>
			</div>
		</div>
		<div class="dropdown">
					<button class="dropbtn">Export</button>
			<div class="dropdown-content">
				<a href="newexport.php">New Export</a>
				<a href="viewexport.php">View Export</a>
				<a href="updateexport.php">Update Export</a>
				<a href="deleteexport.php">Delete Export</a>
			</div>
		</div>
			<div class="dropdown">
				<form method="POST">
			<button class="dropbtn" name="logbtn">LOGOUT</button>
		</form>
		<?php
include "connection.php";
if (isset($_POST["logbtn"])) {
	session_destroy();
	header("location:user.php");
}
		?>
		</div>