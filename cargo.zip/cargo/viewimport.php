<?php 
session_start();
if (!isset($_SESSION["password"])) {
 header("location:user.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
	<title>View Furniture IMported</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="layout">
	<div class="bunner"><center><h1>Welcome To Cargo Ltd</h1></center></div>
	<div class="menu"><?php  include "menu.php";  ?></div>
	<div class="content">
		<center>
			<h1><u>View IMport Furniture</u></h1>
			<?php
include "connection.php";
$query=mysqli_query($con,"SELECT * from import order by i_id asc");
echo "<table border='1' bgcolor='pink'>";
echo "<tr>";
echo "<th>"."No"."</th>"."<th>"."Imported Date"."</th>"."<th>"."Imported Quantity"."</th>";
echo "</tr>";
$x=1;
while ($row=mysqli_fetch_array($query)) {
	echo "<tr>";
	echo "<td>"; echo $x; echo "</td>";
	echo "<td>"; echo $row["i_date"]; echo "</td>";
	echo "<td>"; echo $row["i_quantity"]; echo "</td>";
	echo "</tr>";
	$x++;
}
echo "</table>";
			?>
		</center>
	</div>
	<div class="footer"><center><p>All@reserved by Cargo Ltd</p></center></div>
</div>
</body>
</html>
<?php
}
?>