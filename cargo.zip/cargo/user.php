<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login here</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="layout">
	<div class="bunner"><center><h1>Welcome To Cargo Ltd</h1></center></div>
	<div class="menu"></div>
	<div class="content">
		<center>
			<h1><u>Login Here</u></h1>
			<form method="POST">
		    <table bgcolor="pink">
		    <tr><td>Username</td><td><input type="text" name="uname" placeholder="Enter Username" required=""></td></tr>
			<tr><td>Password</td><td><input type="password" name="pwd" placeholder="Enter Password" required=""></td></tr>
			<tr><td></td><td><input type="submit" name="loginbtn" value="Login"></td></tr>
				</table>
			</form>
			<?php
include "connection.php";
if (isset($_POST["loginbtn"])) {
$query=mysqli_query($con,"SELECT * from manager where username='$_POST[uname]' and password='$_POST[pwd]'");
$check=mysqli_num_rows($query);
if ($check>0) {
	while ($row=mysqli_fetch_array($query)) {
		$_SESSION["password"]=$row["password"];
		header("location:home.php");
	}
}
else
{
	echo "<script>alert('Username And Password Are Incorrect')</script>";
}
}
			?>
		</center>
	</div>
	<div class="footer"><center><p>All@reserved by Cargo Ltd</p></center></div>
</div>
</body>
</html>