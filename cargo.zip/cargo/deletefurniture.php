<?php 
session_start();
if (!isset($_SESSION["password"])) {
 header("location:user.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
	<title>Delete Furniture</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="layout">
	<div class="bunner"><center><h1>Welcome To Cargo Ltd</h1></center></div>
	<div class="menu"><?php  include "menu.php";  ?></div>
	<div class="content">
		<center>
			<h1><u>Delete Furniture</u></h1>
			<form method="POST">
				<table bgcolor="pink">
					<tr><td><select name="sel">
						<option>Choose Furniture Name</option>
						<?php
						include "connection.php";
$query=mysqli_query($con,"SELECT * from furniture ");
while ($row=mysqli_fetch_array($query)) {
						?>
						<option><?php  echo $row["f_name"];  ?></option>
					<?php } ?>
					</select>
					<input type="submit" name="chkbtn" value="Check">
					</td>
				</tr>
				</table>
			</form>
<br>
			<?php
include "connection.php";
if (isset($_POST["chkbtn"])) {
	$query=mysqli_query($con,"SELECT * from furniture where f_name='$_POST[sel]'");
while ($row=mysqli_fetch_array($query)) {
			?>
			<form method="POST"> 	
				<table bgcolor="pink">
					<tr><td></td><td><input type="hidden" name="fid" value="<?php  echo $row['f_id']; ?>"></td></tr>
					<tr><td>Furniture Name</td><td><input type="text" name="fname" value="<?php  echo $row['f_name']; ?>" readonly></td></tr>
					<tr><td>Furniture Owner Name</td><td><input type="text" name="owner" placeholder="Enter Furniture Owner Name" required="" value="<?php  echo $row['f_owner_name']; ?>" readonly></td></tr>
					<tr><td></td><td><input type="submit" name="savebtn" value="Delete"></td></tr>
				</table>
			</form>
		<?php }} ?>
		<?php
include "connection.php";
if (isset($_POST["savebtn"])) {
	$query=mysqli_query($con,"DELETE from furniture  where f_id='$_POST[fid]'");
	if ($query) {
		echo "<script>alert('Delete Furniture Successfully')</script>";
	}
}
		?>
		</center>
	</div>
	<div class="footer"><center><p>All@reserved by Cargo Ltd</p></center></div>
</div>
</body>
</html>
<?php
}
?>