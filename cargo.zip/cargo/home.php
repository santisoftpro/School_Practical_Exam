<?php 
session_start();
if (!isset($_SESSION["password"])) {
 header("location:user.php");
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="layout">
	<div class="bunner"><center><h1>Welcome To Cargo Ltd</h1></center></div>
	<div class="menu"><?php  include "menu.php";  ?></div>
	<div class="content"></div>
	<div class="footer"><center><p>All@reserved by Cargo Ltd</p></center></div>
</div>
</body>
</html>
<?php
}
?>